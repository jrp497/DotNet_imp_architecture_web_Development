﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using bo;
using dal;

namespace bll
{
    public class Candidate_bll
    {
        public int adddata(Candidate_bo obj2)
        {
            Candidate_dal data = new Candidate_dal();
            data.scheduleBGC(obj2);
            return 0;
        }
    }
}
