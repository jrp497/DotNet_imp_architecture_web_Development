﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using bo;
using System.Data.SqlClient;
using System.Data.Sql;


namespace dal
{
    public class Candidate_dal
    {
        public int scheduleBGC(Candidate_bo obj1)
        {
            string connectionString = "Data Source= ingnrilpsql02; Initial Catalog = A104; User ID=a36; Password= a36";

            SqlConnection connection = new SqlConnection(connectionString);


            string query = "insert into mod3_Candidatecheck values('"+obj1.BID+"','"+obj1.fdate+"','"+obj1.tdate+"',"+obj1.adminID+")";
            SqlCommand cmd = new SqlCommand(query, connection);


            connection.Open();
            int result = cmd.ExecuteNonQuery();
            connection.Close();
            return 0;
           

        }
    }
}
