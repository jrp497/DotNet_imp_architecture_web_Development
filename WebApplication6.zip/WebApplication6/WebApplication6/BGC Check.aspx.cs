﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using bo;
using bll;

namespace BGC
{
    public partial class BGC_Check : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           

        }

      
        protected void Button1_Click(object sender, EventArgs e)
        {
           
        //   DateTime da = Convert.ToDateTime(TextBox1.Text);
        //   DateTime da1 = Convert.ToDateTime(TextBox2.Text);
        //   if (da < System.DateTime.Now)
        //   {
        //       Label3.Visible = true;
        //       Label3.Text = ("Invalid From Date");
        //   }
        //   else if (da1 <= System.DateTime.Now)
        //   {
        //       Label3.Visible = true;
        //       Label3.Text = ("Invalid To Date");
        //   }
        //   else
        //   {

            Candidate_bo data = new Candidate_bo();
            data.adminID = Convert.ToInt16(DropDownList1.Text);
            data.fdate = Convert.ToDateTime(TextBox1.Text);
            data.tdate = Convert.ToDateTime(TextBox2.Text);
            data.BID ="";

            Candidate_bll data1 = new Candidate_bll();
            data1.adddata(data);

            Response.Redirect("BGC Status.aspx");
        }
        }
    }


