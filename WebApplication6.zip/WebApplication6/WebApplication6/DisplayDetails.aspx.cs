﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label2.Text = Request.QueryString["emp"];
            Label3.Text = Request.QueryString["dob"];
            Label4.Text = Request.QueryString["loc"];
            
            Label6.Text = Request.QueryString["doj"];
            Label7.Text = Request.QueryString["ctc"];
            Label8.Text = Request.QueryString["des"];
            Label9.Text = Request.QueryString["unit"];
            Label10.Text = Request.QueryString["id"];
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            Response.Redirect("edit.aspx?n="+Label2.Text);
        }

        
    }
}