﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication6
{
    public partial class ViewAdministrator1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label29.Text = Request.QueryString["name"].ToString();
            //Label30.Text = Request.QueryString["name1"].ToString() ;
            Label31.Text = Request.QueryString["name2"].ToString();
        }

        protected void Button10_Click(object sender, EventArgs e)
        {
            Response.Redirect("UserLogin.aspx");
        }
    }
}