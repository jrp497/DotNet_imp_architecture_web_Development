﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication6
{
    public partial class ApproveAdministrator : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
             Label29.Text = Request.QueryString["name"];
            Label30.Text = Request.QueryString["name1"];
             Label31.Text = Request.QueryString["name2"].ToString();
             
        }

        protected void Button9_Click(object sender, EventArgs e)
        {
           Response.Redirect("ViewAdministrator1.aspx?name=" + Label29.Text  + "&name2=" + Label31.Text);
        }

      
        protected void Button10_Click(object sender, EventArgs e)
        {
            DropDownList1.Visible = true;
            
        }
        protected void Button12_Click(object sender, EventArgs e)
        {
            DropDownList2.Visible = true;

        }
        protected void Button13_Click(object sender, EventArgs e)
        {
            DropDownList3.Visible = true;

        }
        protected void Button14_Click(object sender, EventArgs e)
        {
            DropDownList4.Visible = true;

        }

        protected void Button15_Click(object sender, EventArgs e)
        {
          //  //if (Button10_Click())
          //  //{

            //Label21.Text = DropDownList1.Text;
            //DropDownList1.Visible = false;
          //  //}
          // // else if (Button12_Click)
          //  //{
          //      Label24.Text = DropDownList2.Text;
          //      DropDownList2.Visible = false;
          // // }
          ////  else if (Button13_Click = true)
          ////  {
          //      Label27.Text = DropDownList3.Text;
          //      DropDownList3.Visible = false;
          ////  }
          ////  else
          //  {
            Label30.Text = DropDownList4.Text;
            DropDownList4.Visible = false;
           // }
        }


      
    }
}