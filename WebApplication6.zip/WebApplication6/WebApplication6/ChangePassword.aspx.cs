﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication6
{
    public partial class ChangePassword : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

       
        protected void Button1_Click1(object sender, EventArgs e)
        {
            //if (TextBox1.Text != "Tata@1234")
            //    Label5.Text = "Default Password unmatched";
             if (TextBox2.Text != TextBox3.Text)
                Label5.Text = "New Password & Confirm Password unmatched";
            //else if ((TextBox1.Text != "Tata@1234") && (TextBox2.Text != TextBox3.Text))
            //    Label5.Text = "Please check the passwords again";
           
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("main.aspx");
        }
    }
}