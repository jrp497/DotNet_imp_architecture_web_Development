﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BGC
{
    public partial class BGC_Status : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label7.Text = Request.QueryString["st"];
           

        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            Response.Redirect("candidateprofile.aspx");
           
            
        }

       

        protected void Button81_Click(object sender, EventArgs e)
        {
            Response.Redirect("candidateprofile.aspx");
        }

        protected void Button9_Click(object sender, EventArgs e)
        {
            Response.Redirect("candidateprofile.aspx");
        }

      
        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("DisplayStatus.aspx?s="+Label7.Text);
        }
    }
}