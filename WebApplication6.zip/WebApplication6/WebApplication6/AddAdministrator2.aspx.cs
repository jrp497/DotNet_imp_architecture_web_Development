﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication6
{
    public partial class AddAdministrator2 : System.Web.UI.Page
    {
        public string id=null,status=null,date=null;
        public AddAdministrator2()
        {
           
        }
        public AddAdministrator2(string id,string status,string date,DropDownList DropDownList2)
        {   
            this.id=id;
            this.status=status;
            this.date=date;
        }
    
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (DropDownList2.Text == "Select")
                Label32.Text = "Please select a valid ID";

            else
            {
                Label32.Visible = false;
                Label3.Visible = true;
                Label4.Visible = true;
                Label6.Visible = true;
                Label23.Visible = true;
                Label20.Visible = true;
                Label21.Visible = true;
                Label22.Visible = true;
                Label24.Visible = true;
                Label25.Visible = true;
                Label26.Visible = true;
                Label27.Visible = true;
                Label28.Visible = true;
                if ((DropDownList2.Text == "739159") || (DropDownList2.Text == "739009") || (DropDownList2.Text == "784561") || (DropDownList2.Text == "763254") || (DropDownList2.Text == "747846"))
                {
                    Label29.Visible = true;
                    Label29.Text = DropDownList2.Text;
                    Label30.Visible = true;
                    Label30.Text = "Awaiting Approval";
                    Label31.Visible = true;
                    DateTime Date = System.DateTime.Now;
                    string D = Convert.ToString(Date);
                    Label31.Text = D;
                }
                Button2.Visible = true;
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("ApproveAdministrator.aspx?name=" + Label29.Text + "&name1=" + Label30.Text + "&name2=" + Label31.Text);
            
        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
      
    }
}