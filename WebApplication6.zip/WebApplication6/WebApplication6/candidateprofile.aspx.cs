﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BGC
{
    public partial class candidateprofile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                TextBox17.Attributes.Add("onChange", "myID();");
                TextBox18.Attributes.Add("onChange", "myID1();");
                TextBox21.Attributes.Add("onChange", "my10per();");
                TextBox22.Attributes.Add("onChange", "my12per();");
                
            }
        }

        protected void Button21_Click(object sender, EventArgs e)
        {
            TextBox17.Text = "";
            TextBox18.Text = "";
            TextBox19.Text = "";
            TextBox20.Text = "";
            TextBox21.Text = "";
                      
            TextBox22.Text = "";
            TextBox23.Text = "";
            TextBox24.Text = ""; 
            TextBox26.Text = "";
            TextBox27.Text = "";
            DropDownList11.Text = "";
            DropDownList12.Text = "";
            DropDownList13.Text = "";
            

        }

        protected void Button22_Click(object sender, EventArgs e)
        {

            Response.Redirect("BGC Status.aspx?st=" +DropDownList13.Text);
        }
    }
}