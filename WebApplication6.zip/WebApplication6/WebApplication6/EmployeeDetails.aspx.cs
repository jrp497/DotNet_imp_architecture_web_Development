﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
           Response.Redirect("DisplayDetails.aspx?emp=" + TextBox1.Text + "&dob=" + DropDownList6.Text + "/" + DropDownList7.Text + "/" + DropDownList8.Text + "&loc=" + DropDownList9.Text+"&doj="+DropDownList3.Text+"/"+DropDownList4.Text+"/"+DropDownList5.Text+"&ctc="+TextBox5.Text+"&des="+TextBox6.Text+"&unit="+DropDownList2.Text+"&id="+DropDownList1.Text);
      
        }

        protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void DropDownList6_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        protected void DropDownList8_SelectedIndexChanged(object sender, EventArgs e)
        {
            
           // int year = Convert.ToInt32(DropDownList8.Text);
           // string mon = Convert.ToString(DropDownList6.Text);
           // int day = Convert.ToInt32(DropDownList7.Text);
           //if (year != 1984 || year != 1988 || year != 1992)
           // {
           //     if (mon == "Feb" && (day == 29 || day == 30 || day == 31))
           //     { Label11.Text = ("Invalid Date"); }
           // }
        }

        protected void TextBox7_TextChanged(object sender, EventArgs e)
        {

        }
    }
}