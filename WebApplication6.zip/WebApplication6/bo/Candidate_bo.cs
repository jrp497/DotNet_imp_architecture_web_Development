﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace bo
{
    public class Candidate_bo
    {
        public int adminID;
        public DateTime fdate;
        public DateTime tdate;
        public string BID;
    }
}
