﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Types;
using BO_Layer;

namespace FactoryBO
{
    public class BookBOFactory
    {
        public static IBook objDB;
        public static IBook createBOObject()
        {
            if (objDB == null)
            {
                objDB = new Book();
            }
            return objDB;
        }
    }
}
