﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Types;
using FactoryDAL;

namespace BLL_Layer
{
    public class BookBLL : IBLL
    {
       
        IDAL Dobj = FactoryDAL.BookDBFactory.createDALObject();
        public int AddBook(IBook b)
        {
            int res;
            if (b.rating <= 3)
            {
                b.fine = b.cost * 2;

            }
            else
            {
                b.fine = b.cost * 5;
            }

            res = Dobj.insertBook(b);
            return res;
        }
    }
}
