﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using FactoryBO;
using FactoryBLL;
using Types;

namespace UI_Layer
{
    public partial class AddBook : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }



        protected void Button1_Click(object sender, EventArgs e)
        {
            IBook Bobj = BookBOFactory.createBOObject();
            IBLL BLLObj = BookBLLFactory.createBLLObject();
            Bobj.name = TextBox1.Text;
            Bobj.cost = Convert.ToDouble(TextBox2.Text);
            Bobj.rating = Convert.ToInt16(TextBox3.Text);

            int r = BLLObj.AddBook(Bobj);
            if (r > 0)
                Label4.Text = "Record has been successfully added with ID"+r;
            else
                Label4.Text = " Addition Unsuccessful.  Sorry";
        }
    }
}