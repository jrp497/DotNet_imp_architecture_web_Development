﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Types
{
    public interface IBLL
    {
        int AddBook(IBook b);
    }
}
