﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Types
{
    public interface IBook
    {
        string name { get; set; }
        int id { get; set; }        
        double cost  { get; set; }
        int rating { get; set; }
        double fine { get; set; }
    }
}
