﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Types
{
    public interface IDAL
    {
        int insertBook(IBook bObject);
    }
}
