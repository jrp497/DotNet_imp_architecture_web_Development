﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Types;
using BLL_Layer;

namespace FactoryBLL
{
    public class BookBLLFactory
    {
        public static IBLL objDB;
        public static IBLL createBLLObject()
        {
            if (objDB == null)
            {
                objDB = new BookBLL();
            }
            return objDB;
        }
    }
}
