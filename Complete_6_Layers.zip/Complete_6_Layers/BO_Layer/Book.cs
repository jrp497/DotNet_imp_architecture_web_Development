﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Types;

namespace BO_Layer
{
    public class Book : IBook
    {
        int Id;
        string Name;
        double Cost;
        int Rating;
        double Fine;

      
        public string name
        {
            get
            {
                return Name;
            }
            set
            {
                Name = value;
            }
        }
        public double cost
        {
            get
            {
                return Cost;
            }
            set
            {
                Cost = value;
            }
        }
        public int rating
        {
            get
            {
                return Rating;
            }
            set
            {
                Rating = value;
            }
        }
        public double fine
        {
            get
            {
                return Fine;
            }
            set
            {
                Fine = value;
            }
        }
        public int id
        {
            get
            {
                return Id;
            }
            set
            {
                Id = value;
            }
        }

    }
}
