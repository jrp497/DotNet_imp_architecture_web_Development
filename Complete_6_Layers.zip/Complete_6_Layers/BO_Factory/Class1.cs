﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BO_Factory
{
    public class Class1
    {
    }
}
