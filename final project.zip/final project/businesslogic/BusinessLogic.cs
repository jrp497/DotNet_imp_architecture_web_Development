﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using businessobject;
using DAL;
using System.Collections;
using System.Data;

namespace businesslogic
{
    public class BusinessLogic
    {
        DataAccess d = new DataAccess();
        public void ad(BusinessObject b1)
        {
            d.view(b1);
        }
        public void ad1(BusinessObject b1)
        {
            d.view1(b1);
        }
        public void bgcstatus1(BusinessObject b1)
        {
            d.bgcstatus(b1);
        }
        public void viewcandidate1(BusinessObject b1)
        {
            d.viewcandidate(b1);
        }
        public void updatecandidate(BusinessObject b1)
        {
            d.updatecandidate1(b1);
        }
        public void addEmp(BusinessObject bo)
        {

            d.addEmp1(bo);
            
        }
        public DataTable displayEmp(BusinessObject bo1)
        {
            return d.displayEmp1(bo1);
        }

        public int editEmp1(BusinessObject bo2)
        {

            return d.editEmp(bo2);
        }
        public void unithead(BusinessObject bobj)
        {
            d.unithead1(bobj);
        }
        public void unithead1(BusinessObject bobj)
        {
            d.unithead11(bobj);
        }


        string pwd;
        public int checkpwd(BusinessObject b)
        {

            pwd = d.getP(b);
            if (pwd == b.password)
                return 1;
            else
                return 0;


        }
        public void funcf(BusinessObject u)
        {
            d.funcr(u);
        }
        public string ret(BusinessObject c)
        {
            return pwd;
        }

        public int getp(BusinessObject p)
        {
            return (d.gan(p));
        }
        

        // function for retrieving data for admin table  
                public DataTable src(BusinessObject bc)
        {

            return (d.search(bc));
        }
        
        // function for dropdown data for add admin
        public void getdata(BusinessObject c)
        {
            d.show(c);
        }

        // fn for adding admin to admin table
        public int chng(int nam)
        {
            return(d.sett(nam));
            // return for error check
        }
        public void approveadmin(BusinessObject b1)
        {
            d.approveadmin1(b1);
        }
        public void changestatus(BusinessObject b1)
        {
            d.changestatus1(b1);
        }
        public void ax(BusinessObject b1)
        {
            d.ax1(b1);
        }
        public void view(BusinessObject b1)
        {
            d.view2(b1);
        }
        public void viewdetail(BusinessObject b1)
        {
            d.viewdetail2(b1);
           
        }
        public void ge1(BusinessObject b1)
        {
            d.ge(b1);
        }

    }
}
