﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Data;

namespace businessobject
{
    public class BusinessObject
    {
        public Int32 BGC_ID, Administrator_ID, Candidate_Profile_ID, Test_Id, Medical_Test_Status, BGC_Test_Status, Vacancy_ID;
        public DateTime From_date, To_date, DOB;
        public String Location, Gender, Remarks,candidate_name;
        public Int32 Gap_In_Education, Gap_In_Experience;
        public Double Percentage_10th, Percentage_12th;
        public ArrayList a = new ArrayList();
        public ArrayList a1 = new ArrayList();
        public DataTable dt = new DataTable();
        public int id, UnitHeadID, ProjID;
        public string Name, Gender1, Division, Design;
        public DateTime DOB1, DOJ;
        public double CTC;
        public int UserId;
        public string password, oldpwd, nwpwd, confpwd;
        public string name, status;
        public DateTime statustime;

    }

}
//create table mod3_CandidateBGCcheck(BGC_ID int,From_date datetime,To_date datetime,
//Administrator_ID int)

//create table mod3_CandidateProfile(Candidate_Profile_ID int,Vacancy_ID int,
//DOB datetime,Location varchar(30),Gender varchar(10),Percentage_10th float,
//Percentage_12th float,Gap_In_Education varchar(40),
//Gap_In_Experience varchar(40),
//Resume_file varchar(30),Test_Id int,Medical_Test_Status bit,BGC_ID int,
//BGC_Test_Status bit,Remarks varchar(30))
