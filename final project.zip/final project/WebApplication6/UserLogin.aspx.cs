﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using businesslogic;
using businessobject;

namespace WebApplication6
{
    public partial class UserLogin : System.Web.UI.Page
    {
        BusinessObject bobj = new BusinessObject();
        BusinessLogic bllobj = new BusinessLogic();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           
            bobj.UserId = Convert.ToInt32(TextBox1.Text);  //storing the value of textbox in variable       
            bobj.password = TextBox2.Text;

            int f = bllobj.checkpwd(bobj);    //checking password of database and ui
            if (f == 1)
            {
                Response.Redirect("ChangePassword.aspx?emp=" + TextBox2.Text + "&def=" + TextBox1.Text + "");
                Label1.Visible = false;
            }
            else
                Label1.Visible = true;       //you have entered wrong entry
           
        }

        
    }
}