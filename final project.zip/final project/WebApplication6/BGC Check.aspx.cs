﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using businesslogic;
using businessobject;
using System.Collections;


namespace BGC
{
    
    public partial class BGC_Check : System.Web.UI.Page
    {
        BusinessLogic b = new BusinessLogic();
        BusinessObject b1 = new BusinessObject();
       
        protected void Page_Load(object sender, EventArgs e)
        {
            Button1.Visible = false;
            b.ad(b1);
            DropDownList3.DataSource=b1.a;
            DropDownList3.DataBind();
            DropDownList3.Items.Insert(0, new ListItem("select", "0"));
        }


        protected void Button1_Click(object sender, EventArgs e)
        {

            b1.Administrator_ID = Convert.ToInt32(DropDownList3.SelectedItem.Value);
            b1.From_date = Convert.ToDateTime(TextBox1.Text);
            b1.To_date = Convert.ToDateTime(TextBox2.Text);


            DateTime dt1 = DateTime.Now.Date;
            DateTime dt2 = Convert.ToDateTime(TextBox1.Text.Trim()).Date;
            DateTime dt3 = Convert.ToDateTime(TextBox2.Text.Trim()).Date;
            if (dt1 > dt2 || dt2 > dt3)
            {
                if (dt1 <= dt2)
                { Label1.Visible = false; }
                else
                {
                    Label1.Text = "Entered date is less than current date";
                    Label1.Visible = true;
                }


                if (dt2 < dt3)
                {
                    Label3.Visible = false;
                }
                else
                {
                    Label3.Text = "Entered date is less than from date";
                    Label3.Visible = true;
                }
            }

            else
            {

                if (dt3 > dt2.AddDays(7))
                {
                    Label3.Text = "Entered date is 7 days more than from date";
                    Label3.Visible = true;
                }
                else
                {
                    Label3.Visible = false;




                    b.ad1(b1);

                    Label4.Text = Convert.ToString("The BGC Id generate is " + b1.BGC_ID);
                    Label4.Visible = true;
                    Button1.Visible = true;
                }
            }
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            Response.Redirect("BGC Status.aspx");

        }

        //protected void Button2_Click(object sender, EventArgs e)
        //{
        //    TextBox1.Text = "";
        //    TextBox2.Text = "";
        //    Label1.Visible = false;
        //    Label3.Visible = false;
            
        //    //Response.Redirect("BGC Status.aspx");
        //}

      
       
    }

}
