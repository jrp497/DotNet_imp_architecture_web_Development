﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using businesslogic;
using businessobject;

namespace WebApplication6
{
    public partial class ChangePassword : System.Web.UI.Page
    {
       // BusinessObject g = new BusinessObject();
        BusinessLogic h = new BusinessLogic();
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void Button1_Click1(object sender, EventArgs e)
        { string p;
        int i, j, g = 0;
            if (TextBox2.Text != TextBox3.Text)    //comparing the values of two new password entered in textbox 
            {
                Label37.Visible = true;    //display password does not match
            }
            else
            {
                BusinessObject ga = new BusinessObject();
                ga.password = Request.QueryString["psw"];    //storing the password from database into variable
                ga.Name = Request.QueryString["emp"];       //storing the userid from database into variable
                p= TextBox2.Text; 
                  Random r = new Random();
            int n = r.Next(1, 9);
            
            string ep=string.Empty;
            for ( j=0,i=n; j < p.Length; ++i,++j)
            {
                g = (int)p[j];
                g = g + ((2*i)+1);
                char enc = (char)g;
                ep = ep+enc;
            }
            char t=(char)n;
            ep = ep + t;
                ga.nwpwd=ep;

                
                //storing the new password into variable
                int u = h.getp(ga);                          // calling the function from BLL layer 
                if (u == 1)
                {
                    
                    Response.Redirect("main.aspx");      //redirect to main page

                }
                else
                {
                    Label35.Visible = false;
                    Label36.Visible =false;

                   
                }
            }
       
        }

     
    }
}