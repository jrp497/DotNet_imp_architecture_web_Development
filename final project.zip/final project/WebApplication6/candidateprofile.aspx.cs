﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using businesslogic;
using businessobject;

namespace BGC
{
    public partial class candidateprofile : System.Web.UI.Page
    {
        BusinessLogic b = new BusinessLogic();
        BusinessObject b1 = new BusinessObject();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["Name"] != null)
                    b1.Candidate_Profile_ID = Convert.ToInt32(Request.QueryString["Name"]);
                b.viewcandidate1(b1);
                TextBox30.Text = Convert.ToString(b1.candidate_name);
                TextBox17.Text = Convert.ToString(b1.Candidate_Profile_ID);
                TextBox18.Text = Convert.ToString(b1.Vacancy_ID);
                TextBox19.Text = Convert.ToString(b1.DOB);
                TextBox20.Text = b1.Location;
                TextBox21.Text = Convert.ToString(b1.Percentage_10th);
                TextBox22.Text = Convert.ToString(b1.Percentage_12th);
                TextBox23.Text = Convert.ToString(b1.Gap_In_Education);
                TextBox24.Text = Convert.ToString(b1.Gap_In_Experience);
                TextBox26.Text = Convert.ToString(b1.Test_Id);
                TextBox27.Text = Convert.ToString(b1.BGC_ID);
                if (b1.Gender == "male")
                    RadioButton1.Checked = true;
                else
                    RadioButton2.Checked = true;
                if (b1.Medical_Test_Status == 1)

                    TextBox29.Text = "Cleared";
                else
                    TextBox29.Text = "Pending";

                if (b1.BGC_Test_Status == 0)
                {
                    DropDownList13.Text = "Pending";
                    TextBox28.Visible = true;
                }
                else
                {
                    DropDownList13.Text = "Cleared";
                    TextBox28.Visible = false;
                }
                TextBox28.Text = b1.Remarks;
            }
        }

      

        protected void Button22_Click1(object sender, EventArgs e)
        {
            if (DropDownList13.SelectedItem.Value == "Pending")
            {
                b1.BGC_Test_Status = 0;
            }
            else
                if (DropDownList13.SelectedItem.Value == "Cleared")
                {
                    b1.BGC_Test_Status = 1;
                }
            b1.Candidate_Profile_ID = Convert.ToInt32(TextBox17.Text);
            b1.Remarks = TextBox28.Text;
            b.updatecandidate(b1);
           
        }

        protected void Button23_Click(object sender, EventArgs e)
        {
            Response.Redirect("webstatus1.aspx");
        }

       

      
        protected void DropDownList13_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownList13.SelectedItem.Value == "Pending")
            {
                TextBox28.Visible = true;
            }
            else
                TextBox28.Visible = false;
        }
       
       
    }
}