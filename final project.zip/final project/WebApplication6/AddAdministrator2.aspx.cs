﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using businessobject;
using businesslogic;
using System.Data;

namespace WebApplication6
{
    public partial class AddAdministrator2 : System.Web.UI.Page
    {
        BusinessLogic b = new BusinessLogic();
        BusinessObject hg = new BusinessObject();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                b.getdata(hg);
                DropDownList1.DataSource = hg.a;
                DropDownList1.DataBind();
                DropDownList1.Items.Insert(0, new ListItem("select", "0"));
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
                int ide = Convert.ToInt16(DropDownList1.Text);
              int rt=  b.chng(ide);
              if (rt == 0)
              {
                  Label3.Visible = true;
                  
              }
              else
              {
                  b.getdata(hg);
                  DropDownList1.DataSource = hg.a;
                  DropDownList1.DataBind();
                  DropDownList1.Items.Insert(0, new ListItem("select", "0"));
                 
                  BusinessLogic bk = new BusinessLogic();
                  BusinessObject bc = new BusinessObject();
                  DataTable dat = bk.src(bc);
                  GridView1.DataSource = dat;
                  GridView1.DataBind();
                  GridView1.Visible = true;
                 
                  DropDownList1.ClearSelection();
                 
              }
              }

      

        protected void Button2_Click1(object sender, EventArgs e)
        {
            Response.Redirect("hr_start.aspx");
        }

        protected void pagefunc(object sender, GridViewPageEventArgs e)
        {
            BusinessLogic bk = new BusinessLogic();
            BusinessObject bc = new BusinessObject();

            GridView1.PageIndex = e.NewPageIndex;

            DataTable dat = bk.src(bc);
            GridView1.DataSource = dat;
            GridView1.DataBind();
        }

        
    }
}