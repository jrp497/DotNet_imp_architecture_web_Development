﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using businesslogic;
using businessobject;
using System.Text;

namespace WebApplication2
{
    public partial class edit : System.Web.UI.Page
    {
        BusinessObject bobj1 = new BusinessObject();
        BusinessLogic bllobj1 = new BusinessLogic();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
               FillCapctha();
                bllobj1.unithead1(bobj1);
                DropDownList3.DataSource = bobj1.a;
                DropDownList3.DataBind();
                bobj1.a.Clear();
                bllobj1.unithead(bobj1); // to auto populate the unitheadID and Project ID in dropdown
                DropDownList5.DataSource = bobj1.a;
                DropDownList5.DataBind();
                bobj1.a.Clear();
                DropDownList3.Items.Insert(0, new ListItem("select", "0"));
                DropDownList5.Items.Insert(0, new ListItem("select", "0"));
                DropDownList4.Items.Insert(0, new ListItem("select", "0"));
              
            }
        } void FillCapctha()
        {
            try
            {
                Random random = new Random();
                string combination = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz%@#*&$";
                StringBuilder captcha = new StringBuilder();
                for (int i = 0; i < 6; i++)
                    captcha.Append(combination[random.Next(combination.Length)]);
                Session["captcha"] = captcha.ToString();
                imgCaptcha.ImageUrl = "Generate_Captcha.aspx?" + DateTime.Now.Ticks.ToString();
            }
            catch
            {


                throw;
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            if (Session["captcha"].ToString() == txtCaptcha.Text)
            {
                Label21.Text = "Valid Captcha Code";

            }
            else
            {
                Label21.Text = "Invalid Captcha Code";
                FillCapctha();
            }
            
        }

        protected void btnRefresh_Click(object sender, EventArgs e)
        {
            FillCapctha();
        }

    }
}
        protected void Button1_Click(object sender, EventArgs e)
        {
            if (DropDownList3.SelectedIndex != 0 && DropDownList4.SelectedIndex != 0 && DropDownList5.SelectedIndex != 0)
            {
                bobj1.Name = DropDownList3.SelectedValue;
                bobj1.Design = DropDownList4.SelectedValue;
                bobj1.CTC = Convert.ToInt64(TextBox2.Text);
                bobj1.UnitHeadID = Convert.ToInt16(DropDownList5.SelectedValue);
                int r = bllobj1.editEmp1(bobj1);

                if (r > 0)
                {
                    Label35.Text = "Updated successfully";
                    Label35.Visible = true;
                }
                else
                    Label35.Text = "Not Updated";
            }
            else
            {
                Label35.Text = "Please select the appropriate values!";
                Label35.Visible = true;
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("hr_start.aspx");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("DisplayDetails.aspx");
        }

        
    }
}