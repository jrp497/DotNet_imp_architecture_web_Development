﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using businesslogic;
using businessobject;
using System.Data;
using System.Collections;

namespace BGC
{
    public partial class BGC_Status : System.Web.UI.Page
    {
        BusinessLogic b = new BusinessLogic();
        BusinessObject b1 = new BusinessObject();
        protected void Page_Load(object sender, EventArgs e)
        {

            b.bgcstatus1(b1);
            GridView1.DataSource = b1.dt;
            GridView1.DataBind();

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            if (Hiddenfield1.Value == "")
            {
                Label16.Text = "First please select an employee";
            }
            else
            {
                b1.Candidate_Profile_ID = Convert.ToInt32(Hiddenfield1.Value);
                Response.Redirect("candidateprofile.aspx?Name=" + b1.Candidate_Profile_ID);
            }
    }
        protected void gvSample_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (e.Row.Cells[2].Text.Contains("1") || e.Row.Cells[3].Text.Contains("1"))
                {
                    e.Row.Cells[2].Text = e.Row.Cells[2].Text.Replace("1", "Cleared");
                    e.Row.Cells[3].Text = e.Row.Cells[3].Text.Replace("1", "Cleared");
                }
                 if (e.Row.Cells[3].Text.Contains("0") || e.Row.Cells[2].Text.Contains("0"))
                {
                    e.Row.Cells[3].Text = e.Row.Cells[3].Text.Replace("0", "Pending");
                    e.Row.Cells[2].Text = e.Row.Cells[2].Text.Replace("0", "Pending");
                }
               
            }
        }

        
    }
}