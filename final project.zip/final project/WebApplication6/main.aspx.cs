﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using businesslogic;
using businessobject;


namespace WebApplication4
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        BusinessObject b = new BusinessObject();
        BusinessLogic b1 = new BusinessLogic();
        protected void Page_Load(object sender, EventArgs e)
        {
            TextBox1.Attributes.Add("onchange()", "vali();");
        }
        protected void Button1_Click(object sender, EventArgs e)
        {

            b.UserId = Convert.ToInt32(TextBox1.Text);

            b.password = TextBox2.Text;
          
           b1.funcf(b);
           if (b.Design == "HR")
           {
               if (b.password == "ram")
                   Response.Redirect("ChangePassword.aspx?emp=" + TextBox1.Text + "&psw=" + TextBox2.Text + "");
              else
                   Response.Redirect("hr_start.aspx");
           }
           else if (b.Design == "Unit Head")
           {
               if (b.password == "ram")
                   Response.Redirect("ChangePassword.aspx?emp=" + TextBox1.Text + "&psw=" + TextBox2.Text + "");
               else

                   Response.Redirect("UNITui.aspx");
           }
           else if (b.Design == "Admin")
           {
               if (b.password == "ram")
                   Response.Redirect("ChangePassword.aspx?emp=" + TextBox1.Text + "&psw=" + TextBox2.Text + "");
               else
                   Response.Redirect("Admin.aspx");
           }
           else if (b.Design == "Employee")
           {
               if (b.password == "ram")
                   Response.Redirect("ChangePassword.aspx?emp=" + TextBox1.Text + "&psw=" + TextBox2.Text + "");
               else
                   Response.Redirect("emp_enter.aspx");
           }
           else
               Label7.Visible = true;
          
        }

        protected void Button2_Click(object sender, EventArgs e)
        { BusinessObject bobj = new BusinessObject();
        BusinessLogic bllobj = new BusinessLogic();
        bobj.UserId = Convert.ToInt32(TextBox1.Text);
        bobj.password = TextBox2.Text;

            int f = bllobj.checkpwd(bobj);
            if (f == 1)
            {
                Response.Redirect("ChangePassword.aspx?emp=" + TextBox1.Text + "&psw=" + TextBox2.Text + "");
                
            }
            else
            {
                Label7.Visible = true;
        }

        }
    }
}