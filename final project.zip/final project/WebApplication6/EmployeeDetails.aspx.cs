﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using businesslogic;
using businessobject;
namespace WebApplication2
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        BusinessLogic bllObj = new BusinessLogic();
        BusinessObject bobj = new BusinessObject();
        protected void Page_Load(object sender, EventArgs e)
        {
            Label38.Visible = false;
            if (!IsPostBack)
            {
                bllObj.unithead(bobj); // to auto populate the unitheadID and Project ID in dropdown
                DropDownList3.DataSource = bobj.a;
                DropDownList3.DataBind();
                bobj.a.Clear();
                DropDownList4.DataSource = bobj.a1;
                DropDownList4.DataBind();

                bllObj.view(bobj); // to auto populate the employee name in dropdown
               
                DropDownList5.DataSource = bobj.a;
                DropDownList5.DataBind();
                bobj.candidate_name = DropDownList5.SelectedValue;
                bllObj.viewdetail(bobj); // to retrieve the DOB and GENDER of the selected employee from Database
                TextBox7.Text = Convert.ToString(bobj.DOB);
                TextBox10.Text = bobj.Gender;
            }
           
           
               
        }
        protected void DropDownList5_SelectedIndexChanged1(object sender, EventArgs e)
        {

            bobj.candidate_name = DropDownList5.SelectedValue;
            bllObj.viewdetail(bobj); // to retrieve the DOB and GENDER of the selected employee from Database
            TextBox7.Text = Convert.ToString(bobj.DOB);
            TextBox10.Text = bobj.Gender;

        }
      

        protected void Button1_Click(object sender, EventArgs e)
        {
            bobj.Name = DropDownList5.SelectedValue;
            bobj.DOB1 = DateTime.Parse(TextBox7.Text);
            bobj.DOJ = DateTime.Parse(TextBox8.Text);
            
            bobj.Gender1 = TextBox10.Text;
            bobj.Division = TextBox9.Text;
            bobj.CTC = Convert.ToDouble(TextBox11.Text);
            bobj.Design = DropDownList6.SelectedValue;

            bobj.UnitHeadID = Convert.ToInt16(DropDownList3.SelectedValue);
            bobj.ProjID = Convert.ToInt16(DropDownList4.SelectedValue);
           //insert
            if (bobj.DOB1 == bobj.DOJ || bobj.DOJ < bobj.DOB1 || bobj.DOJ > DateTime.Now.Date)
            {
                Label38.Text = "Enter Date of Joining other than DOB and lesser than Todays date & DOB!!";
                Label38.Visible = true;
            }
            else
            {
                bllObj.addEmp(bobj); // to insert the employee details in database

                bllObj.ge1(bobj);
                Response.Redirect("DisplayDetails.aspx");
            }
        }

       

       
    }
}