﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using businesslogic;
using businessobject;
using System.Data;
using System.Collections;

namespace WebApplication6
{
    public partial class webstatus1 : System.Web.UI.Page
    {
        BusinessLogic b = new BusinessLogic();
        BusinessObject b1 = new BusinessObject();
        protected void Page_Load(object sender, EventArgs e)
        {
            b1.a.Clear();
            b.bgcstatus1(b1);
            GridView1.DataSource = b1.dt;
            GridView1.DataBind();

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Admin.aspx");
        }
        protected void gvSample_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (e.Row.Cells[1].Text.Contains("1"))
                {
                    e.Row.Cells[1].Text = e.Row.Cells[1].Text.Replace("1", "Cleared");
                    
                }
                if (e.Row.Cells[2].Text.Contains("0"))
                {
                    e.Row.Cells[2].Text = e.Row.Cells[2].Text.Replace("0", "Pending");
                    
                }
                if(e.Row.Cells[2].Text.Contains("1"))
                {e.Row.Cells[2].Text = e.Row.Cells[2].Text.Replace("1", "Cleared");}
                if(e.Row.Cells[2].Text.Contains("0"))
                {e.Row.Cells[1].Text = e.Row.Cells[1].Text.Replace("0", "Pending");}
            }
        }
    }
}