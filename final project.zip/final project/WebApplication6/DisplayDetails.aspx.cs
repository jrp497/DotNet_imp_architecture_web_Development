﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using businessobject;
using businesslogic;
using System.Data;

namespace WebApplication2
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            BusinessObject bobj = new BusinessObject();
            BusinessLogic bllobj = new BusinessLogic();
            DataTable dt = bllobj.displayEmp(bobj);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            Response.Redirect("edit.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("hr_start.aspx");
        }

        protected void pagefunc(object sender, GridViewPageEventArgs e)
        {
            BusinessObject bobj = new BusinessObject();
            BusinessLogic bllobj = new BusinessLogic();
            GridView1.PageIndex = e.NewPageIndex;
            DataTable dt = bllobj.displayEmp(bobj);
            GridView1.DataSource = dt;
            GridView1.DataBind();
 
        }
    }
}