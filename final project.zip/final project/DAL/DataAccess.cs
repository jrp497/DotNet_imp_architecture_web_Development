﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using businessobject;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Collections;
using System.Data;

namespace DAL
{
    public class DataAccess
    {
        static string connectionString = "Data Source= ingnrilpsql02; Initial Catalog = A104; User ID=a36; Password= a36";
        SqlConnection connection = new SqlConnection(connectionString);
        public void view(BusinessObject b1)
        {
            try
            {
                string query = "select admin_id from admin555 where status='Approved'";
                connection.Open();
                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {

                    b1.a.Add(dr[0].ToString());

                }
            }
            catch (Exception ex)
            { throw ex; }
            finally
            {
            connection.Close();
            }

        }
        public void funcr(BusinessObject ol)
        {
            try
            {
                string query = " select Designation from tab123 where userid=" + ol.UserId + " and pwd ='" + ol.password + "'";
                connection.Open();
                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {

                    ol.Design = dr[0].ToString();

                }
            }
            catch (Exception ex)
            { throw ex; }
            finally
            {
                connection.Close();
            }

        }
        public void view1(BusinessObject b1)
        {
            try
            {
                string query = "insert into mod3_CandidateBGCcheck(From_date,To_date,Administrator_ID) values('" + b1.From_date + "','" + b1.To_date + "','" + b1.Administrator_ID + "')";

                connection.Open();
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.ExecuteNonQuery();

                string query1 = "select BGC_ID from mod3_CandidateBGCcheck where Administrator_ID=" + b1.Administrator_ID;
                SqlCommand cmd1 = new SqlCommand(query1, connection);

                SqlDataReader dr = cmd1.ExecuteReader();
                while (dr.Read())
                {

                    b1.BGC_ID = Convert.ToInt32(dr[0].ToString());

                }
                dr.Close();
            }

            catch (Exception ex)
            { throw ex; }
            finally
            {
                connection.Close();
            }
        }
        public void bgcstatus(BusinessObject b1)
        {
            try
            {
                string query1 = "select Candidate_Profile_ID,Medical_Test_Status,BGC_Test_Status from mod3_CandidateProfile";

                connection.Open();
                SqlCommand cmd = new SqlCommand(query1, connection);
                SqlDataAdapter ad = new SqlDataAdapter(cmd);
                ad.Fill(b1.dt);
            }

            catch (Exception ex)
            { throw ex; }
            finally
            {
                connection.Close();
            }
        }
        public void viewcandidate(BusinessObject b1)
        {
            try
            {
                string query1 = "select * from mod3_CandidateProfile where Candidate_Profile_ID=" + b1.Candidate_Profile_ID;

                SqlCommand cmd = new SqlCommand(query1, connection);
                connection.Open();
                string query5 = "select BGC_ID from mod3_CandidateBGCcheck";
                SqlCommand cmd1 = new SqlCommand(query5, connection);

                SqlDataReader dr6 = cmd1.ExecuteReader();
                while (dr6.Read())
                {

                    b1.BGC_ID = Convert.ToInt32(dr6[0].ToString());

                }
                dr6.Close();
                string query2 = "update mod3_CandidateProfile set BGC_ID=" + b1.BGC_ID + " where Candidate_Profile_ID=" + b1.Candidate_Profile_ID;
                SqlCommand cmd3 = new SqlCommand(query2, connection);
                cmd3.ExecuteNonQuery();
                cmd.ExecuteNonQuery();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    b1.candidate_name = dr[14].ToString();
                    b1.Candidate_Profile_ID = Convert.ToInt32(dr[0].ToString());
                    b1.Vacancy_ID = Convert.ToInt32(dr[1].ToString());
                    b1.DOB = Convert.ToDateTime(dr[2].ToString());
                    b1.Location = dr[3].ToString();
                    b1.Gender = dr[4].ToString();
                    b1.Percentage_10th = Convert.ToDouble(dr[5].ToString());
                    b1.Percentage_12th = Convert.ToDouble(dr[6].ToString());
                    b1.Gap_In_Education = Convert.ToInt32(dr[7].ToString());
                    b1.Gap_In_Experience = Convert.ToInt32(dr[8].ToString());
                    b1.Test_Id = Convert.ToInt32(dr[9].ToString());
                    b1.Medical_Test_Status = Convert.ToInt32(dr[10].ToString());
                    b1.BGC_ID = Convert.ToInt32(dr[13].ToString());
                    b1.BGC_Test_Status = Convert.ToInt32(dr[11].ToString());
                    b1.Remarks = dr[12].ToString();
                }
                dr.Close();
            }


            catch (Exception ex)
            { throw ex; }
            finally
            {
                connection.Close();
            }
        }
        public void updatecandidate1(BusinessObject b1)
        {
            try
            {

                string query2 = "update mod3_CandidateProfile set Remarks='" + b1.Remarks + "',BGC_Test_Status='" + b1.BGC_Test_Status + "' where Candidate_Profile_ID=" + b1.Candidate_Profile_ID;
                connection.Open();
                SqlCommand cmd3 = new SqlCommand(query2, connection);
                cmd3.ExecuteNonQuery();
            }
            catch (Exception ex)
            { throw ex; }
            finally
            {
                connection.Close();
            }
        }
        public void addEmp1(BusinessObject bo1)       // To insert Employee details in database
        {
            try
            {

                string query = "insert into mod3_Employee1 values('" + bo1.Name + "','" + bo1.DOB1 + "','" + bo1.DOJ + "','" + bo1.Gender1 + "','" + bo1.Division + "','" + bo1.CTC + "','" + bo1.Design + "','" + bo1.UnitHeadID + "','" + bo1.ProjID + "')";

                SqlCommand cmd = new SqlCommand(query, connection);
                connection.Open();
                int r = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            { throw ex; }
            finally
            {
                connection.Close();
            }
            
        }
        public DataTable displayEmp1(BusinessObject bo)      // To display the employee lists on UI
        {
            try
            {

                string query = "select * from mod3_Employee1";
                SqlConnection connection = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand(query, connection);
                DataTable d = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(d);
                return (d);
            }
            catch (Exception ex)
            { throw ex; }
            finally
            {
                connection.Close();
            }
        }

        public int editEmp(BusinessObject bo2)          //To update the Designation and CTC of the selected employee in database
        {
            try
            {

                string query = "update mod3_Employee1 set Designation='" + bo2.Design + "', CTC=" + bo2.CTC + ",UnitHeadID=" + bo2.UnitHeadID + " where EmpName='" + bo2.Name + "'";

                SqlCommand cmd = new SqlCommand(query, connection);
                connection.Open();
                int u = cmd.ExecuteNonQuery();
                return u;
            }

            catch (Exception ex)
            { throw ex; }
            finally
            {
                connection.Close();
            }
           
        }
        public void unithead1(BusinessObject bobj)      // To retrieve Employee ID & Project ID from database
        {
            try
            {
                string query = "select EmpID from mod3_Employee1 where UnitHeadID is NULL";

                connection.Open();
                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {

                    bobj.a.Add(dr[0].ToString());

                } dr.Close();

                string query1 = "select ProjectID from mod3_UnitHead";


                SqlCommand cmd1 = new SqlCommand(query1, connection);
                SqlDataReader dr1 = cmd1.ExecuteReader();

                while (dr1.Read())
                {

                    bobj.a1.Add(dr1[0].ToString());

                }
            }


            catch (Exception ex)
            { throw ex; }
            finally
            {
                connection.Close();
            }

        }
        public void unithead11(BusinessObject bobj)    // To retrieve Employee name & UnitheadID from database
        {
            try
            {
                string query = "select EmpName from mod3_Employee1 where UnitHeadID is not NULL";

                connection.Open();
                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {

                    bobj.a.Add(dr[0].ToString());

                } dr.Close();

                string query1 = "select UnitHeadid from mod3_UnitHead";


                SqlCommand cmd1 = new SqlCommand(query1, connection);
                SqlDataReader dr1 = cmd1.ExecuteReader();

                while (dr1.Read())
                {

                    bobj.a1.Add(dr1[0].ToString());

                }
            }
            catch (Exception ex)
            { throw ex; }
            finally
            {
                connection.Close();
            }

            
        }
        // updating the table with new password.
        public int gan(BusinessObject j)
        {
            try
            {

                SqlCommand cmd1 = new SqlCommand("update tab123 set pwd='" + j.nwpwd + "' where pwd ='" + j.password + "'and userid='" + j.Name + "'", connection);
                connection.Open();
                int resd = cmd1.ExecuteNonQuery();
                return resd;
            }
            catch (Exception ex)
            { throw ex; }
            finally
            {
                connection.Close();
            }
            
        }
        // taking password from database for main page.

        public string getP(BusinessObject b)
        {
            try
            {
                string us = "n";
                int i = 0;
                SqlCommand cmd1 = new SqlCommand("SELECT pwd FROM tab123 WHERE userid='" + b.UserId + "'", connection);
                connection.Open();
                SqlDataReader dr = cmd1.ExecuteReader();
                while (dr.Read())
                {
                    us = dr[i].ToString();

                }
                return (us);
            }
            catch (Exception ex)
            { throw ex; }
            finally
            {
                connection.Close();
            }
            
        }

        //function for displaying data for admin table on Hr page 
        public DataTable search(BusinessObject bc)
        {
            try
            {

                string query = "Select * from admin555 ";
                SqlCommand com = new SqlCommand(query, connection);
                DataTable dt = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(com);
                adapter.Fill(dt);
                return (dt);
            }
            catch (Exception ex)
            { throw ex; }
            finally
            {
                connection.Close();
            }

          
        }
        public int sett(int id)
        {
            try
            {
                string query = "exec sp_ad " + id + "";
                string query1 = "update mod3_Employee1 set Designation='Emp/Admin' where EmpID='" + id + "'";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand com = new SqlCommand(query, conn);
                SqlCommand com1 = new SqlCommand(query1, conn);
                conn.Open();
                int a = com.ExecuteNonQuery();
                com1.ExecuteNonQuery();
                return a;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            return 0;
            }
            finally
            {
                connection.Close();
            }
           
            
        }
        // function for giving values for admin selection
        public void show(BusinessObject v)
        {
            try
            {
                string query = "select EmpID from mod3_Employee1 where Designation='Employee'";
                SqlCommand com = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader rd = com.ExecuteReader();
                while (rd.Read())
                {
                    v.a.Add(Convert.ToInt16(rd[0].ToString()));

                }
            }
            catch (Exception ex)
            { throw ex; }
            finally
            {
                connection.Close();
            }
        }
        public void approveadmin1(BusinessObject b1)
        {
            try
            {
                string query1 = "select * from admin555 where status != 'Approved'";
                connection.Open();
                SqlCommand cmd = new SqlCommand(query1, connection);
                SqlDataAdapter ad = new SqlDataAdapter(cmd);
                ad.Fill(b1.dt);
            }

            catch (Exception ex)
            { throw ex; }
            finally
            {
                connection.Close();
            }
        }
        public void changestatus1(BusinessObject b1)
        {
            try
            {
                string query2 = "update admin555 set status ='" + b1.status + "',Status_time='" + b1.statustime + "' where admin_id=" + b1.UserId;
                connection.Open();
                SqlCommand cmd3 = new SqlCommand(query2, connection);
                cmd3.ExecuteNonQuery();
                if (b1.status == "Approved")
        { string query1 =" update mod3_Employee1 set Designation ='Admin' where EmpID=" +b1.id;
           string query = "update tab123 set Designation ='Admin' from tab123 T inner join admin555 A on T.userid=A.emp_id";
                    SqlCommand cmd4 = new SqlCommand(query, connection);
                    SqlCommand cmd6 = new SqlCommand(query1, connection);
                    cmd4.ExecuteNonQuery();
                    cmd6.ExecuteNonQuery();
                }
                if (b1.status == "Rejected")
                {
                    string query = "update mod3_Employee1 set Designation ='Employee' where EmpID= "+b1.id;
                    SqlCommand cmd5 = new SqlCommand(query, connection);
                    cmd5.ExecuteNonQuery();

                }
            }

            catch (Exception ex)
            { throw ex; }
            finally
            {
                connection.Close();
            }

        }// hye
        public void ax1(BusinessObject b1)
        {
            try
            {
                string query1 = "select * from admin555";

                connection.Open();
                SqlCommand cmd = new SqlCommand(query1, connection);
                SqlDataAdapter ad = new SqlDataAdapter(cmd);
                ad.Fill(b1.dt);
            }

            catch (Exception ex)
            { throw ex; }
            finally
            {
                connection.Close();
            }

        }
        public void view2(BusinessObject b1)     // To retrieve candidate name from database.
        {
            try
            {
                string query = "select candidate_name from mod3_CandidateProfile where BGC_Test_Status=1";
                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    b1.a.Add(dr[0].ToString());
                }
            }

            catch (Exception ex)
            { throw ex; }
            finally
            {
                connection.Close();
            }

        }
        public void viewdetail2(BusinessObject b1)   // To retrieve DOB and Gender for the selected Employee from database
        {
            try
            {
                string query = "select DOB,Gender from mod3_CandidateProfile where candidate_name= '" + b1.candidate_name + "'";

                SqlConnection conn = new SqlConnection(connectionString);
                SqlCommand cmd1 = new SqlCommand(query, conn);
                conn.Open();
                cmd1.ExecuteNonQuery();
                SqlDataReader dr = cmd1.ExecuteReader();
                while (dr.Read())
                {
                    b1.Gender = dr[1].ToString();
                    b1.DOB = Convert.ToDateTime(dr[0].ToString());
                }
            }

            catch (Exception ex)
            { throw ex; }
            finally
            {
                connection.Close();
            }
        }
        
            public void ge(BusinessObject b1)   // To retrieve Employee id from database
            {
                try
                {
                    int fd = 0;
                    int g = 0;
                    string query1 = "select EmpID from mod3_Employee1 where EmpName='" + b1.Name + "'";
                    SqlConnection conn = new SqlConnection(connectionString);
                    SqlCommand cmd5 = new SqlCommand(query1, conn);
                    conn.Open();
                    cmd5.ExecuteNonQuery();
                    SqlDataReader dr1 = cmd5.ExecuteReader();
                    while (dr1.Read())
                    {
                        fd = Convert.ToInt32(dr1[0]);
                    }
                    g = fd;
                    string query2 = "insert into tab123 values (" + g + ",'ram','" + b1.Design + "')";
                    SqlConnection conn1 = new SqlConnection(connectionString);
                    SqlCommand cmd6 = new SqlCommand(query2, conn1);
                    conn1.Open();
                    cmd6.ExecuteNonQuery();
                    conn.Close();
                    conn1.Close();
                }
                
                catch (Exception ex)
                { 
                    throw ex; 
                }
                finally
                {
                    
                }

        }
    }
}

